#ifndef UI_H
#define UI_H

#include <imgui.h>
#include <GLFW/glfw3.h>
#include "particle_system.h"

void setupImGui(GLFWwindow* window);
void renderUI(ParticleSystem& particleSystem, bool& attract);

#endif // !UI_H

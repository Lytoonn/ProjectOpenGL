#ifndef CONFIG_H
#define CONFIG_H

const unsigned int SCR_WIDTH = 1920;
const unsigned int SCR_HEIGHT = 1080;

#endif // !CONFIG.H

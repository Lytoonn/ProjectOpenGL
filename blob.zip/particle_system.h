#ifndef PARTICLE_SYSTEM_H
#define PARTICLE_SYSTEM_H

#include <glm/glm.hpp>
#include <vector>

struct Particle {
	glm::vec2 position;
	glm::vec2 velocity;
	float lifetime;
	glm::vec4 color;
};

class ParticleSystem {
public:
	ParticleSystem(int maxParticles);
	void update(float deltaTime, bool rightMousePressed, bool attract, glm::vec2 cursorPos);
	void resetParticle(int index, glm::vec2 position);
	std::vector<Particle>& getParticles();

private:
	std::vector<Particle> particles;
	int maxParticles;
	float particleVelocity;
	float particleLifetime;
	glm::vec4 particleColor;
};

#endif // !PARTICLE_SYSTEM.H

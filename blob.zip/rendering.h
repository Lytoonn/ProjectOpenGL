#ifndef RENDERING_H
#define RENDERING_H

#include <vector>
#include <glm/glm.hpp>
#include "particle_system.h"

class Renderer {
public:
	Renderer();
	void setup();
	void render(const std::vector<Particle>& particles);
	unsigned int getShaderProgram();

private:
	unsigned int VAO, VBO, shaderProgram;
	glm::mat4 projection;
};

#endif // !RENDERING_H

#include "ui.h"
#include <imgui_impl_glfw.h>
#include <imgui_impl_opengl3.h>

void setupImGui(GLFWwindow* window) {
	IMGUI_CHECKVERSION();
	ImGui::CreateContext();
	ImGui::StyleColorsDark();
	ImGui_ImplGlfw_InitForOpenGL(window, true);
	ImGui_ImplOpenGL3_Init("#version 330");
}

void renderUI(ParticleSystem& particleSystem, bool& attract) {
	ImGui_ImplOpenGL3_NewFrame();
	ImGui_ImplGlfw_NewFrame();
	ImGui::NewFrame();

	ImGui::Begin("Particle Settings");
	if (ImGui::Button(attract ? "Repel Particles" : "Attract Particles")) {
		attract = !attract;
	}
	ImGui::End();

	ImGui::Render();
	ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}
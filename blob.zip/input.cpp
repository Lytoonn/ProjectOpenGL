#include "input.h"

double mouseX = 0.0, mouseY = 0.0;

void processInput(GLFWwindow* window, bool& leftMousePressed, bool& rightMousePressed) {
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) glfwSetWindowShouldClose(window, true);
}

void cursor_position_callback(GLFWwindow* window, double xPos, double yPos) {
	mouseX = xPos;
	mouseY = yPos;
}

glm::vec2 getWorldPositionFromMouse(double mouseX, double mouseY) {
	return glm::vec2(mouseX, mouseY);
}
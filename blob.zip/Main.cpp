#include <iostream>
#include <GLFW/glfw3.h>
#include <glad/glad.h>
#include "config.h"
#include "particle_system.h"
#include "rendering.h"
#include "input.h"
#include "ui.h"

int main() {

	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	if (!glfwInit()) {
		std::cerr << "Failed to initialize GLFW" << std::endl;
		return -1;
	}



	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Particle System", nullptr, nullptr);
	if (!window) {
		glfwTerminate();
		return -1;
	}

	glfwMakeContextCurrent(window);
	glewInit();

	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
		std::cerr << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	Renderer renderer;
	renderer.setup();
	ParticleSystem particleSystem(2000);
	setupImGui(window);

	bool leftMousePressed = false, rightMousePressed = false, attract = true;
	glm::vec2 cursorPos(0.0f, 0.0f);

	while (!glfwWindowShouldClose(window)) {
		float deltaTime = glfwGetTime();
		processInput(window, leftMousePressed, rightMousePressed);
		particleSystem.update(deltaTime, rightMousePressed, attract, cursorPos);

		glClear(GL_COLOR_BUFFER_BIT);
		renderUI(particleSystem, attract);
		renderer.render(particleSystem.getParticles());

		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwTerminate();
	return 0;
}
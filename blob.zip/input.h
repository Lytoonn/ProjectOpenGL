#ifndef INPUT_H
#define INPUT_H

#include <GLFW/glfw3.h>
#include <glm/glm.hpp>

void processInput(GLFWwindow* window, bool& leftMousePressed, bool& rightMousePressed);
void cursor_position_callback(GLFWwindow* window, double xpos, double ypos);
glm::vec2 getWorldPositionFromMouse(double mouseX, double mouseY);

#endif
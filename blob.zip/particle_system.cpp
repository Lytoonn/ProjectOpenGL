#include "particle_system.h"
#include <cstdlib>
#include <glm/gtc/matrix_transform.hpp>

ParticleSystem::ParticleSystem(int maxParticles) :
	maxParticles(maxParticles), particleVelocity(100.0f), particleLifetime(5.0f), particleColor(1.0f, 1.0f, 1.0f, 1.0f) {
	particles.resize(maxParticles);
}

void ParticleSystem::update(float deltaTime, bool rightMousePressed, bool attract, glm::vec2 cursorPos) {
    for (auto& particle : particles) {
        if (particle.lifetime > 0.0f) {
            if (rightMousePressed) {
                glm::vec2 direction = attract ? (cursorPos - particle.position) : (particle.position - cursorPos);
                float length = glm::length(direction);
                if (length > 0.0f) direction /= length;
                particle.velocity += direction * particleVelocity * deltaTime;
            }
            particle.position += particle.velocity * deltaTime;
            particle.lifetime -= deltaTime;
        }
    }
}

void ParticleSystem::resetParticle(int index, glm::vec2 position) {
    particles[index].position = position;
    particles[index].velocity = glm::vec2(
        (static_cast<float>(rand()) / RAND_MAX - 0.5f) * particleVelocity,
        (static_cast<float>(rand()) / RAND_MAX - 0.5f) * particleVelocity
    );
    particles[index].lifetime = static_cast<float>(rand()) / RAND_MAX * particleLifetime;
    particles[index].color = particleColor;
}

std::vector<Particle>& ParticleSystem::getParticles() {
    return particles;
}